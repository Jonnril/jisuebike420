-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2024 at 08:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jisu_pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `is_ban` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=not_ban,1=ban',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `phone`, `is_ban`, `created_at`) VALUES
(6, 'Ching_fu', 'admin@gmail.com', '$2y$10$TrXr12kJXr8Osn.O8Ef3w.L2m7/.LsEJI8bEsNOAlkjaJALRXGTOq', '09489937567', 0, '2024-07-22');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `status`) VALUES
(20, 'jisu1', 'www', 0),
(21, 'jisu2', 'ss', 0),
(22, 'jisu3', 'dd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `status`, `created_at`) VALUES
(22, 'ching sedurifa', 'chingfu@gmail.com', '09489937567', 0, '2024-07-19'),
(23, 'johnyy', 'ved@gmail.com', '09506203861', 0, '2024-07-20'),
(27, 'Mich Pedroza', 'michped@gmail.com', '09096391158', 0, '2024-07-21'),
(28, 'Jessa Mae', 'jess10@gmail.com', '09987867564', 0, '2024-07-21');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `tracking_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `total_amount` varchar(100) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `payment_mode` varchar(100) NOT NULL COMMENT 'cash, online',
  `order_placed_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `tracking_no`, `invoice_no`, `total_amount`, `order_date`, `order_status`, `payment_mode`, `order_placed_by_id`) VALUES
(62, 22, '26227', 'INV-804925', '30000', '2024-07-22', 'booked', 'Cash Payment', 4);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `price`, `quantity`) VALUES
(39, 24, 2, '15000', '1'),
(40, 24, 6, '11000', '1'),
(41, 25, 2, '15000', '1'),
(42, 25, 6, '11000', '1'),
(43, 26, 2, '15000', '1'),
(44, 26, 6, '11000', '1'),
(45, 27, 2, '15000', '1'),
(46, 27, 6, '11000', '1'),
(47, 28, 2, '15000', '1'),
(48, 28, 6, '11000', '1'),
(49, 29, 2, '15000', '1'),
(50, 29, 6, '11000', '1'),
(51, 30, 2, '15000', '1'),
(52, 30, 6, '11000', '1'),
(53, 31, 2, '15000', '1'),
(54, 31, 6, '11000', '1'),
(55, 32, 2, '15000', '1'),
(56, 32, 6, '11000', '1'),
(57, 33, 2, '15000', '1'),
(58, 33, 6, '11000', '1'),
(59, 34, 2, '15000', '1'),
(60, 34, 6, '11000', '1'),
(61, 35, 6, '11000', '1'),
(62, 35, 9, '15000', '1'),
(63, 36, 6, '11000', '1'),
(64, 37, 10, '15000', '3'),
(65, 38, 11, '17000', '1'),
(66, 38, 10, '15000', '1'),
(67, 39, 11, '17000', '1'),
(68, 40, 11, '17000', '1'),
(69, 41, 10, '15000', '4'),
(70, 42, 13, '15', '1'),
(71, 43, 13, '15', '1'),
(72, 44, 14, '15', '1'),
(73, 45, 25, '44', '1'),
(74, 46, 23, '15', '1'),
(75, 47, 25, '15000', '1'),
(76, 48, 26, '15000', '1'),
(77, 49, 28, '15000', '3'),
(78, 50, 26, '15000', '1'),
(79, 51, 26, '15000', '2'),
(80, 52, 30, '15000', '2'),
(81, 53, 32, '15000', '3'),
(82, 54, 33, '15000', '1'),
(83, 55, 34, '11000', '2'),
(84, 56, 35, '11000', '3'),
(85, 57, 29, '11000', '1'),
(86, 58, 29, '11000', '1'),
(87, 59, 31, '11000', '1'),
(88, 60, 36, '15000', '2'),
(89, 61, 36, '15000', '1'),
(90, 62, 37, '15000', '1'),
(91, 62, 38, '15000', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `quantity`, `image`, `status`, `created_at`) VALUES
(37, 21, 'Electric Bike', 'abcdefghijklmnopqrstuvwxyz', 15000, 1, 'assets/uploads/products/1721622053.jpg', 0, '2024-07-22'),
(38, 20, 'ved', 'jsndkandkjbakd', 15000, 1, 'assets/uploads/products/1721622047.jpg', 0, '2024-07-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
