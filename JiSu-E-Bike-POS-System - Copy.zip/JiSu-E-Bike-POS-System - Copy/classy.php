<div class="col-md-3">
            <img src="assets/images/bike3.jpg" alt="Product 3" class="img-fluid w-100" style="object-fit: cover; height: 300px;">
            <p class="text-center">CLASSY PRO 5 SEATERS</p>
        </div>